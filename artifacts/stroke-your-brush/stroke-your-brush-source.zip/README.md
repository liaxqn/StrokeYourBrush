# StrokeYourBrush source code

This archive contains the source for the StrokeYourBrush React + Vite web app.

## Main files
- artifacts/stroke-your-brush/src/App.tsx — app UI, drawing canvas, brushes, animation, persistence, and exports
- artifacts/stroke-your-brush/src/index.css — theme and responsive/mobile layout
- artifacts/stroke-your-brush/package.json — dependencies and scripts
- artifacts/stroke-your-brush/vite.config.ts — Vite configuration

## Run locally
From the project root:

```bash
pnpm install
pnpm --filter @workspace/stroke-your-brush run dev
```

The archive intentionally excludes node_modules, build output, and generated TypeScript metadata.
